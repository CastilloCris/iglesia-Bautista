import PageHero from '../components/PageHero.jsx'
import SectionTitle from '../components/SectionTitle.jsx'

const cells = [
  ['Familia Pérez', 'Centro', 'Jueves – 20:00 hs'],
  ['Familia González', 'Norte', 'Viernes – 19:30 hs'],
  ['Familia Rodríguez', 'Sur', 'Martes – 20:30 hs'],
]

export default function Cells() {
  return (
    <>
      <PageHero title="Células" subtitle="Iglesias en las casas" />
      <section className="container-page px-5 py-16">
        <div className="text-center">
          <SectionTitle>Encuentra tu Célula</SectionTitle>
          <p className="-mt-8 text-gray-300">Busca la que esté más cerca de tu hogar.</p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-3">
          {cells.map(([family, area, time]) => (
            <article key={family} className="card-professional p-8">
              <img src="/img/comunidad.png" alt={family} className="mx-auto mb-5 h-[120px] w-[120px] rounded-full border-4 border-primary object-cover p-2 shadow-md" />
              <h3 className="mb-3 font-serif text-2xl text-primary">{family}</h3>
              <p className="mb-2 text-gray-300">
                <strong className="text-beth-gold">Barrio:</strong> {area}
              </p>
              <p className="text-gray-300">
                <strong className="text-beth-gold">Reunión:</strong> {time}
              </p>
              <a href="https://maps.google.com" target="_blank" rel="noreferrer" className="btn px-6 py-3 text-sm">
                Ver Ubicación
              </a>
            </article>
          ))}
        </div>
      </section>
    </>
  )
}
